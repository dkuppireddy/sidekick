package com.example.project_login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AllJobActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_job);
    }
}